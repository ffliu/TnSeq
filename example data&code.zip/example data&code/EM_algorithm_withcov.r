### the inverse of logit link
invlogit <- function(z)
{return(1 / (1 + exp(-z)))
}

### the first derivative of inverse of logit link
invlogit_deriv<-function(z)
{  
	zz<-	z-2*log(1+exp(z))
	return( exp(zz))
}

### the second derivative of inverse of logit link
invlogit_deriv2<-function(z)
{  
	zz1<-	z-3*log(1+exp(z))
	zz2<-	2*z-3*log(1+exp(z))
	return( exp(zz1)-exp(zz2))
}


lik0<-function(p,mu){
	#p,mu: vector with the same length.
	p+(1-p)*exp(-mu)}




####################################### ############# #############   
############# obtain MLE for parameters using EM algorithm 
####################################### ############# ############# 


## Expectation Step in the EM algorithm
estep <- function(count, muG , beta,X ){
	z_temp<- ifelse(count == 0, invlogit( muG+as.numeric(X%*% beta) ) ,0)
	return(z_temp)
}
## Maximization Step---mu in the EM algorithm
mstep_mu <- function(count ,z_temp){
	at<-tapply(  count*(1-z_temp)  ,  dat$ord ,sum)
	am<-tapply(  (1-z_temp)  ,  dat$ord ,sum)
	mu_temp <- at /am
	return(mu_temp)
}


## Maximization Step---beta in the EM algorithm
mstep_beta <- function(X,z_temp){
  
  oldw <- getOption("warn")
  options(warn = -1)  
  
  ######## remember to change the modeling when the covariates change.
  fit<-glm(z_temp~ as.factor(dat$match)+ dat$GC_percent,family=binomial)
  
  options(warn = oldw)
  
	return(fit$coef)
}


## the main function of EM Algorithm
em.algo <- function(mu_inits,beta_inits,maxit=500,tol=1e-6){

# Initial parameter estimates
	flag <- 0
	mu_cur <- mu_inits; beta_cur <- beta_inits
	

# Iterate between expectation and maximization steps
for(i in 1:maxit){
	cur <- c(mu_cur,beta_cur)
	mu_cur_G <- mu_cur[dat$ord]

	
	z<-estep( y, mu_cur_G, as.numeric(beta_cur), X  )
	mu_new <- mstep_mu( y ,z)
	beta_new <- mstep_beta(X, z) 
	new_step <- c(mu_new,beta_new)
	# Stop iteration if the difference between the current and new estimates is less than a tolerance level
  if( all(abs(cur - new_step) < tol) ){ flag <- 1; break}
  # Otherwise continue iteration
  mu_cur <- mu_new; beta_cur <- beta_new}
  if(!flag) warning("not converge\n")
  list(mu=mu_cur, beta=beta_cur) }






################################################################################   
############# obtain standardard deviation for the difference between the mean for 
############# each of the normal genes with the common mean for pseudogenes
################################################################################ 




###### the estimated second derivative of loglikelihood w.r.t beta
deriv_beta2<-function(betaest,muest){

### betaest: the maximum likelihood estimate of regression coefficient beta
### muest:   the maximum likelihood estimate of mean read count for each normal genes 
### and common mean for pseudogenes.

#return nbet*nbet matrix,
#the estimated second derivative of loglikelihood w.r.t beta
	
  beta<-betaest
  mu<-muest
  mu0 <- mu[N+1]
  muN<- mu[1:N]
  #mu for each site   
  mu<-rep(mu0,nrow(dat))
  mu[dat$gene_type==0]<-rep(muN, lengthN)	
  
  #X<-model.matrix(~as.factor(dat$match))
  p <- invlogit( X%*%beta  )   
	
  mat1<-mat2<-matrix(0,nbet,nbet)
  #mat1
  derivp1<-(  1- exp(-mu))/lik0(p,mu)
  derivp2<-1/(p-1)
  derivp<- ifelse(y == 0, derivp1, derivp2) * invlogit_deriv2(X%*%beta )  
  derivp<-as.numeric(derivp)
 
  for(i in 1:nbet){
  	for (j in 1:nbet)
  	   mat1[i,j]<- t( X[,i] * derivp) %*% X[,j]
  }
  
  #mat2
  derivp21<- - derivp1^2
  derivp22<-  -derivp2^2

  derivp2<-ifelse(y == 0, derivp21, derivp22) * (invlogit_deriv(X%*%beta ))^2

  
    for(i in 1:nbet){
  	for (j in 1:nbet)
  	   mat2[i,j]<- t( X[,i] * derivp2) %*% X[,j]
  }
  
  return(mat1+mat2)
	
	
}


###### the estimated second derivative of loglikelihood w.r.t mu
deriv_mu2<-function(betaest,muest){

### betaest: the maximum likelihood estimate of regression coefficient beta
### muest:   the maximum likelihood estimate of mean read count for each normal genes 
### and common mean for pseudogenes.

### return (N+1)*(N+1) matrix,
### the estimated second derivative of loglikelihood w.r.t mu.

  beta<-betaest
  mu<-muest
  mu0 <- mu[N+1]
  muN<- mu[1:N]
  #mu for each site   
  mu<-rep(mu0,nrow(dat))
  mu[dat$gene_type==0]<-rep(muN, lengthN)	
  #X<-model.matrix(~as.factor(dat$match))

  p <- invlogit( X%*%beta  )   

  deriv_mus2_1<- p*(1-p)* exp(-mu) /(lik0(p,mu))^2
  deriv_mus2_2<- -y/mu^2 
  deriv_mus2 <- ifelse(y== 0, deriv_mus2_1, deriv_mus2_2) 
   
  deriv2<-rep(NA, N+1)  
  deriv2[1]<-sum(deriv_mus2[pos_pseudo])
  deriv2[-1]<-tapply(deriv_mus2[-pos_pseudo], as.numeric(dat[dat$gene_type==0,1]),sum)
    
  return(diag(as.numeric(deriv2)))
	
}



###### the estimated second derivative of loglikelihood w.r.t beta and mu

deriv_betamu<-function(betaest,muest){

### betaest: the maximum likelihood estimate of regression coefficient beta
### muest:   the maximum likelihood estimate of mean read count for each normal genes 
### and common mean for pseudogenes.

### return nbet*N matrix	
### the estimated second derivative of loglikelihood w.r.t beta and mu

  beta<-betaest
  mu<-muest
  mu0 <- mu[N+1]
  muN<- mu[1:N]
  #mu for each site   
  mu<-rep(mu0,nrow(dat))
  mu[dat$gene_type==0]<-rep(muN, lengthN)
	
  #X<-model.matrix(~as.factor(dat$match))
  p <- invlogit( X%*%beta  )   

  derivp1<- exp(-mu)/(lik0(p,mu))^2
  derivp2<-0
  derivp<- ifelse(y == 0, derivp1, derivp2) * invlogit_deriv(X%*%beta )  
  
  mat<-matrix(0,nbet,length(y))

  derivp<-as.numeric(derivp)
  for(i in 1:nbet){
  	   mat[i,]<- t( X[,i] * derivp) 
  }
  
  res<-aggregate(t(mat), list(group=dat$ord), sum)
  return( t(res[,-1])	)
}







###### derive the variance for the difference between the common 
###### mean of pseudogenes and mean of each normal gene and the variance for estimated beta.

deriv_SD_diff<-function(bet,mu){

### bet: the regression coefficients
### mu:   the mean read count for each normal genes 
### and common mean for pseudogenes.


tem_mb<-deriv_betamu(bet,mu)
temp_bet2<-deriv_beta2(bet,mu)
temp_mu2<-deriv_mu2(bet,mu)

#This is the hessian matrix for mu's, not for diff's
hessian<-matrix(0, N+1+nbet, N+1+nbet)
hessian[1:nbet,1:nbet]<- temp_bet2
hessian[(nbet+1):(N+1+nbet),(nbet+1):(N+1+nbet)]<- temp_mu2
hessian[1:nbet,(nbet+1):(N+1+nbet)]<- tem_mb
hessian[(nbet+1):(N+1+nbet), 1:nbet]<- t(tem_mb)
fisher<-solve(-hessian)
var<-diag(solve(-hessian))

#beta, diff
#var[1:nbet]
var_diff<-rep(0,N)
for(i in 1: N)
var_diff[i]<- fisher[i+1+nbet,i+1+nbet]+fisher[1+nbet,1+nbet]-2*fisher[i+1+nbet,1+nbet]

return(var_diff)
}




###### derive the variance for the mean for each of
###### the normal genes 

deriv_SD_mu<-function(bet,mu){

### bet: the regression coefficients
### mu:   the mean read count for each normal genes 
### and common mean for pseudogenes.

  tem_mb<-deriv_betamu(bet,mu)
  temp_bet2<-deriv_beta2(bet,mu)
  temp_mu2<-deriv_mu2(bet,mu)
  
  #This is the hessian matrix for mu's, not for diff's
  hessian<-matrix(0, N+1+nbet, N+1+nbet)
  hessian[1:nbet,1:nbet]<- temp_bet2
  hessian[(nbet+1):(N+1+nbet),(nbet+1):(N+1+nbet)]<- temp_mu2
  hessian[1:nbet,(nbet+1):(N+1+nbet)]<- tem_mb
  hessian[(nbet+1):(N+1+nbet), 1:nbet]<- t(tem_mb)
  
  fisher<-solve(-hessian)
  ## the variance for beta, mu.
  var<-diag(solve(-hessian))
  
  return(var)  
}



